import { StreamChat } from 'stream-chat';

const API_KEY = 'bb4c2hy6axsb'; // TODO: Replace with your actual Stream API key

export const chatClient = StreamChat.getInstance(API_KEY); 